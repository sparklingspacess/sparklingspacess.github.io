To my knowledge the github page for UnknownModder's ScriptHook for MP3 is gone so I've reuploaded the files to here instead.
Just drag dinput8.dll into wherever MaxPayne3.exe is located.